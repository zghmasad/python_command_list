def run():
    print('plugin 2')