def run():
    print('plugin 1')